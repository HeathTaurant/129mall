package Config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import Controller.FileUploadController;
import Controller.MainController;
import Controller.ProductDetailController;
import survey.SurveyController;

@Configuration
public class ControllerConfig {

	/*
	 * @Autowired private MemberRegisterService memberRegSvc;
	 */
	/*
	 * @Bean public RegisterController registerController() { RegisterController
	 * controller = new RegisterController();
	 * controller.setMemberRegisterService(memberRegSvc); return controller; }
	 */	
	/*
	 * @Bean public SurveyController surveyController() { return new
	 * SurveyController(); }
	 */
	
	@Bean
	public MainController mainController() {
		return new MainController();
	}
	@Bean
	public ProductDetailController productDetailController() {
		return new ProductDetailController();
	}
	
	@Bean
	public FileUploadController fileUploadController(){
		return new FileUploadController();
	}
}