package Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import Dao.ProductDetailDao;
import Service.ReviewUploadService;

@Configuration
public class ServiceConfig {
	
    private ProductDetailDao productDetailDao;
	
	
    @Bean
    public ReviewUploadService reviewUploadService() {
    	ReviewUploadService reviewUploadService = new ReviewUploadService(productDetailDao);
    	return  reviewUploadService;
    }
    
}
