package Dto;


public class CartDto {
	int cart_id;
	String mem_userid;
	int it_id;
	int it_color;
	int it_size;
	int cart_count;
	int price;
	int de_price;
	public int getCart_id() {
		return cart_id;
	}
	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}
	public String getMem_userid() {
		return mem_userid;
	}
	public void setMem_userid(String mem_userid) {
		this.mem_userid = mem_userid;
	}
	public int getIt_id() {
		return it_id;
	}
	public void setIt_id(int it_id) {
		this.it_id = it_id;
	}
	public int getIt_color() {
		return it_color;
	}
	public void setIt_color(int it_color) {
		this.it_color = it_color;
	}
	public int getIt_size() {
		return it_size;
	}
	public void setIt_size(int it_size) {
		this.it_size = it_size;
	}
	public int getCart_count() {
		return cart_count;
	}
	public void setCart_count(int cart_count) {
		this.cart_count = cart_count;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getDe_price() {
		return de_price;
	}
	public void setDe_price(int de_price) {
		this.de_price = de_price;
	}
	
	
	
}
