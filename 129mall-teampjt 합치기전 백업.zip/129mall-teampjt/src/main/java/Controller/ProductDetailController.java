package Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import Dto.ItemRequestDto;

@Controller
public class ProductDetailController {

	@GetMapping("/addToCart")
	public String addToCart(ItemRequestDto itemRequestDto, Model model) {
		model.addAttribute("itemRequestDto",itemRequestDto);
		return "Mypage/CartList";
	}

	@GetMapping("/buyNow")
	public String buyNow(ItemRequestDto itemRequestDto, Model model) {
        model.addAttribute("itemRequestDto",itemRequestDto);
		
		return "Mypage/Pay";
	}
	@GetMapping("/review")
	public String review() {

		return "Productdetail/ReviewRegisterForm";
	}

	@GetMapping("/main")
	public String main() {

		return "Productdetail/main";
	}

}