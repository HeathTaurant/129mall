package Service;

import org.springframework.stereotype.Service;

import Dao.ProductDetailDao;

@Service
public class BuyNowService {
	
	private ProductDetailDao productDetailDao;
	
	public BuyNowService(ProductDetailDao productDetailDao) {
		this.productDetailDao= productDetailDao;
	}
	
	
	
	
}
