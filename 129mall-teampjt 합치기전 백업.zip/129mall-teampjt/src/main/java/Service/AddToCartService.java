package Service;

import org.springframework.stereotype.Service;

import Dao.ProductDetailDao;

@Service
public class AddToCartService {
	private ProductDetailDao productDetailDao;

	public AddToCartService(ProductDetailDao productDetailDao) {
		this.productDetailDao = productDetailDao;
	
		
	
	}
	
	
}
