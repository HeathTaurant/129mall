/**
 * 
 */


$('.addTocart').click(function() {
$('#submits').attr("action", "addToCart");
$('#submits').submit();
});

