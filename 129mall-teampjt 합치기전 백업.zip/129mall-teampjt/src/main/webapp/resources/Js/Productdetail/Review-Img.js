/**
 * 
 */


$('.btn_go_review').click(function(){
  var i= document.getElementById("btn_go_review");
        i.scrollIntoView();
});


document.onload(function(){
	if(pageNum==1){
	  var i= document.getElementById("btn_go_review");
        i.scrollIntoView();}
});
	
	

